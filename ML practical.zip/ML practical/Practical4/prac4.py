import pandas as pd
import numpy as np
df=pd.read_csv("Practical4/prac4 - Sheet1.csv")


cdf=df[:6]
n=len(cdf)
print(cdf)


# calculating theta1 theta2

sum_y=cdf['sales'].sum()
sum_x=cdf['gdp'].sum()
sum_xy=(cdf['sales']*cdf['gdp']).sum()
sum_x2=(cdf['gdp']*cdf['gdp']).sum()

theta1=((sum_y*sum_x2)-sum_x*sum_xy)/(n*sum_x2-sum_x*sum_x)
theta2=(n*sum_xy-sum_x*sum_y)/(n*sum_x2-sum_x*sum_x)
# print(theta1,theta2)


# calculating y

y=theta1+theta2*df['gdp'][6]
print(f"old predicted value of y={y}")


# calculating error
cdf=cdf.assign(diff=(theta1+theta2*cdf['gdp'])-cdf['sales'])
# print(cdf)


rmserror=np.sqrt(((cdf['diff']*cdf['diff']).sum())/n)
print(f"error={rmserror}")


# assume aplha=0.5

alpha=0.5
new_theta1=theta1-alpha*((2*(cdf['diff'].sum()))/n)
new_theta2=theta2-alpha*((2*(cdf['diff']*cdf['gdp']).sum())/n)
# print(f"new_theta1={new_theta1},old_theta1={theta1} \nnew_theta2={new_theta2},old_theta2={theta2}")

#new predicted value
new_y=new_theta1+new_theta2*df['gdp'][6]
print(f"new predicted value of y={new_y}")


cdf=cdf.assign(diff2=(new_theta1+new_theta2*cdf['gdp'])-cdf['sales'])
new_rmserror=np.sqrt(((cdf['diff2']*cdf['diff2']).sum())/n)
print(f"new error={new_rmserror}")
print(cdf)

