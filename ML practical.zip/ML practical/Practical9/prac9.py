# implement pca without inbuilt  on the data

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# load the data
data = pd.read_csv('Practical9/prac9.csv')


# calculate the mean of each column
M = np.mean(data.T, axis=1)
# center columns by subtracting column means
C = data - M
# calculate covariance matrix of centered matrix
V = np.cov(C.T)
print("Corelation Matrix: \n",V,"\n")

# eigendecomposition of covariance matrix

values, vectors = np.linalg.eig(V)
print("Eigen Vectors: \n",vectors,"\n")
print("Eigen Values: ",values,"\n")

# project data
P = vectors.T.dot(C.T)
print(P.T)

# plot data
plt.scatter(P[0], P[1])
plt.show()






