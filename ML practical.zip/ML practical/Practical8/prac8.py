# Implemnt KNN

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statistics as s
import math


df=pd.read_csv("Practical8/prac8.csv")
print(df)

VAR1=0.906 
VAR2=0.606


# 1. calculate euclidean distance between VAR1 and VAR2 and each mean

def euclidean_distance(x1,y1,x2,y2):
    return math.sqrt((x1-x2)**2+(y1-y2)**2)

df=df.assign(distance=df.apply(lambda x:euclidean_distance(x['VAR1'],x['VAR2'],VAR1,VAR2),axis=1))
print(df)

# 2. sort the data frame by distance in ascending order

df=df.sort_values(by=['distance'])
print(df)

# 3. select the first 3 rows

df=df.iloc[0:3]
print(df)

# 5. predict the class of the case

print("the class of the case is",s.mode(df['CLASS']))

# 6. plot the data points and the means

plt.scatter(df['VAR1'],df['VAR2'],c=df['CLASS'])
plt.scatter(VAR1,VAR2,c='red')
plt.show()




