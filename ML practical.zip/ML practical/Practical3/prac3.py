#Classify the data into training, testing and validation using random sampling


import pandas as pd
d=pd.read_excel("Practical2/world-data-2023 - Pr2.xls")
# print(d)
# slice the data into training, testing and validation at 70%, 15% and 15% respectively
training = d.sample(frac=0.7, random_state=1)
testing = d.drop(training.index)
print(d.dtypes)
validation = testing.sample(frac=0.5, random_state=1)
testing = testing.drop(validation.index)

print(f"length of training data {len(training)}")
print(f"length of testing data {len(testing)}")
print(f"length of validation data {len(validation)}")

#Plot Normal distribution for Population parameter with mean 0 and sigma 1

import matplotlib.pyplot as plt
import numpy as np

mu, sigma = 0, 1 # mean and standard deviation
s = np.random.normal(mu, sigma, 1000)

plt.hist(s, 30, density=True)
plt.show()








