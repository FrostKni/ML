import random
from typing import List, Tuple

data = [(1.713, 1.586, 0), (0.180, 1.786, 1), (0.353, 1.240, 1), (0.940, 1.566, 0), (1.486, 0.759, 1), (1.266, 1.106, 0), (1.540, 0.419, 1), (0.459, 1.799, 1), (0.773, 0.186, 1)]

def initialize_centroids(k: int, data: List[Tuple[float, float, int]]) -> List[Tuple[float, float]]:
    centroids = []
    var1_min = min(data, key=lambda x: x[0])[0]
    var1_max = max(data, key=lambda x: x[0])[0]
    var2_min = min(data, key=lambda x: x[1])[1]
    var2_max = max(data, key=lambda x: x[1])[1]
    for i in range(k):
        var1 = random.uniform(var1_min, var1_max)
        var2 = random.uniform(var2_min, var2_max)
        centroids.append((var1, var2))
    return centroids

def assign_to_cluster(data: List[Tuple[float, float, int]], centroids: List[Tuple[float, float]]) -> List[int]:
    clusters = []
    for point in data:
        distances = [((point[0]-c[0])**2 + (point[1]-c[1])**2)**0.5 for c in centroids]
        cluster = distances.index(min(distances))
        clusters.append(cluster)
    return clusters

def recalculate_centroids(data: List[Tuple[float, float, int]], clusters: List[int], k: int) -> List[Tuple[float, float]]:
    centroids = []
    for i in range(k):
        cluster_points = [data[j][:2] for j in range(len(data)) if clusters[j] == i]
        if cluster_points:
            centroid = tuple(map(lambda x: sum(x)/len(x), zip(*cluster_points)))
            centroids.append(centroid)
        else:
            centroids.append((0, 0))
    return centroids

def kmeans(k: int, data: List[Tuple[float, float, int]]) -> Tuple[List[Tuple[float, float]], List[int]]:
    centroids = initialize_centroids(k, data)
    clusters = assign_to_cluster(data, centroids)
    while True:
        new_centroids = recalculate_centroids(data, clusters, k)
        new_clusters = assign_to_cluster(data, new_centroids)
        if new_clusters == clusters:
            break
        centroids = new_centroids
        clusters = new_clusters
    return centroids, clusters

centroids, clusters = kmeans(2, data)
print('Final centroids:', centroids)
print('Clusters:', clusters)

import matplotlib.pyplot as plt

plt.scatter([x[0] for x in data], [x[1] for x in data], c=clusters)
plt.scatter([x[0] for x in centroids], [x[1] for x in centroids], c='red')
plt.show()

# predict new data
new_data = [(0.5, 1.2), (1.5, 0.8)]
new_clusters = assign_to_cluster(new_data, centroids)
print('New data:', new_data)
print('New clusters:', new_clusters)

plt.scatter([x[0] for x in data], [x[1] for x in data], c=clusters)
plt.scatter([x[0] for x in centroids], [x[1] for x in centroids], c='red')
plt.scatter([x[0] for x in new_data], [x[1] for x in new_data], c=new_clusters, marker='x')
plt.show()

