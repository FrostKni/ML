# Name:Piyush Kawale
# Reg. No.: 20010586
# Description: Decision tree algorithm

# Import the math module to calculate the logarithm

import math

# Define a function to calculate the entropy of a dataset
def entropy(data):
    num_samples = len(data)
    labels = {}
    for sample in data:
        label = sample[-1]
        if label not in labels:
            labels[label] = 0
        labels[label] += 1
    entropy = 0
    for label in labels:
        probability = labels[label] / num_samples
        entropy -= probability * math.log2(probability)
    return entropy

# Define a function to split a dataset based on a given attribute
def split_dat(data, attribute_index):
    splits = {}
    for sample in data:
        attribute_value = sample[attribute_index]
        if attribute_value not in splits:
            splits[attribute_value] = []
        splits[attribute_value].append(sample)
    return splits

# Define a function to calculate the information gain of a split
def information_gain(data, attribute_index):
    total_entropy = entropy(data)
    splits = split_dat(data, attribute_index)
    weighted_entropy = 0
    for attribute_value in splits:
        split_data = splits[attribute_value]
        probability = len(split_data) / len(data)
        weighted_entropy += probability * entropy(split_data)
    information_gain = total_entropy - weighted_entropy
    return information_gain

# Define a function to find the best attribute to split on
def find_best_attribute(data):
    num_attributes = len(data[0]) - 1
    best_attribute = None
    best_information_gain = 0
    for attribute_index in range(num_attributes):
        attribute_information_gain = information_gain(data, attribute_index)
        if attribute_information_gain > best_information_gain:
            best_attribute = attribute_index
            best_information_gain = attribute_information_gain
    return best_attribute

# Define the decision tree algorithm
def decision_tree(data):
    labels = [sample[-1] for sample in data]
    if len(set(labels)) == 1:
        return labels[0]
    if len(data[0]) == 1:
        return max(set(labels), key=labels.count)
    best_attribute = find_best_attribute(data)
    tree = {best_attribute: {}}
    splits = split_dat(data, best_attribute)
    for attribute_value in splits:
        split_data = splits[attribute_value]
        subtree = decision_tree(split_data)
        tree[best_attribute][attribute_value] = subtree
    return tree

# Test the decision tree algorithm on the "Play tennis" dataset
dataset = [
    ['Sunny', 'Hot', 'High', 'Weak', 'No'],
    ['Sunny', 'Hot', 'High', 'Strong', 'No'],
    ['Overcast', 'Hot', 'High', 'Weak', 'Yes'],
    ['Rain', 'Mild', 'High', 'Weak', 'Yes'],
    ['Rain', 'Cool', 'Normal', 'Weak', 'Yes'],
    ['Rain', 'Cool', 'Normal', 'Strong', 'No'],
    ['Overcast', 'Cool', 'Normal', 'Strong', 'Yes'],
    ['Sunny', 'Mild', 'High', 'Weak', 'No'],
    ['Sunny', 'Cool', 'Normal', 'Weak', 'Yes'],
    ['Rain', 'Mild', 'Normal', 'Weak', 'Yes'],
    ['Sunny', 'Mild', 'Normal', 'Strong', 'Yes'],
    ['Overcast', 'Mild', 'High', 'Strong', 'Yes'],
    ['Overcast', 'Hot', 'Normal', 'Weak', 'Yes'],
    ['Rain', 'Mild', 'High', 'Strong', 'No']
]

tree = decision_tree(dataset)
print(tree)

# Predict for outlook:Sunny; Temperature: hot , Humidity:High and wind:strong
instance = ['Sunny', 'Hot', 'Normal', 'Strong']
def predict(instance, tree):
    attribute = list(tree.keys())[0]
    attribute_index = attribute
    attribute_value = instance[attribute_index]
    subtree = tree[attribute][attribute_value]
    if isinstance(subtree, dict):
        return predict(instance, subtree)
    else:
        return subtree
    
prediction = predict(instance, tree)
print(prediction)

