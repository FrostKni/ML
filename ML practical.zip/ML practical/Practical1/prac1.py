import pandas as pd
#a
d=pd.read_csv("Practical1/world-data-2023.csv")
# print(d)

# #b
# print(d.dtypes)

# #c
# print(d.columns)

# #d
# print(d.fillna('FALSE'))

# #e
print(d[:5])

#f
# n=d.select_dtypes(include=['int64','float64'])
# p=n.columns
# print(d[p].describe(include="all"))

#g
# print(d.sort_values(by="GDP"))

#h
start=('A','I','D','S')
p=d["Country"].str.startswith(start)
l=["Country","Capital/Major City","Birth Rate","Currency-Code","Gasoline Price","GDP"]
print(d[p][l])

#j
import matplotlib.pyplot as plt
d.plot('Infant mortality')
plt.show()



