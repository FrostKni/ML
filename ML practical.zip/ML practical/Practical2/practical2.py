import pandas as p
import numpy as np
import matplotlib.pyplot as plt

# reading xls file
d=p.read_excel('Practical2/world-data-2023 - Pr2.xls')

#1

# dp1=d.isnull()
# print(dp1)

#2

# dp2=d.notnull()
# print(dp2)

#3
# dp3=d.dropna()
# print(dp3)

#4
# dp4=d.fillna(0)
# print(dp4)


#5
# dp5=d.replace(np.nan,"zzz")
# print(dp5)

#6

# plt.bar(d['Longitude'],d['Latitude'])
# plt.show()

#7

# plt.scatter(d['Longitude'],d['Latitude'])
# plt.show()


#8
plt.plot(d['Longitude'],d['Latitude'])
plt.show()